Readme:

Created a quick console application using C#.net .
Prerequisites: .Net framework 4.5 .
Design Decisions :
Used VS2015/C#.net due to my prior experience with this IDE.

Attached Sourcecode ,Application .

Change details(05/03/2019): 

The package is updated with 2 dependency DLLs.



