﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace CB_AF_DeckofCards
{
    class Program
    {
        static HttpClient CB_A = new HttpClient();

        public class CCards
        {
            public int Remaining { get; set; }
            public String  deck_id{ get; set; }

            
        }

        static void Main(string[] args)
        {
            try
            {
                callshufflecards().GetAwaiter().GetResult();
            }
            catch
            {
                Console.WriteLine("Unable to connect to DeckOfcardsapi. Press enter to exit the program");
                Console.ReadLine();
            }

        }

        private static async Task callshufflecards()
        {
            try
            {
                CB_A.BaseAddress = new Uri("https://deckofcardsapi.com/");
                CB_A.DefaultRequestHeaders.Accept.Clear();


                CCards ccobj = await GetShuffleCards("api/deck/new/shuffle/?deck_count=1");
                int Original = ccobj.Remaining;
                String ideck_id = ccobj.deck_id;
                // Console.WriteLine("just suffled the deck,deck id is " + ideck_id + "  " + initRemaining);
                // Console.ReadLine();
                Random randobj = new Random();

                CCards ccobjdrw = null;

                int iActual = Original;

                for (int ic = 1; ic <= 5; ic++)


                {
                    int NextC = randobj.Next(1, 6);

                    ccobjdrw = await GetShuffleCards("/api/deck/" + ideck_id + "/draw/?count=" + NextC);
                    //Console.WriteLine("Draw This many cards on this Pass" + NextC + " number of cards in the Deck after Previous Pass " + ccobjdrw.Remaining);
                    Console.WriteLine("Your Deck id is " + ideck_id + " Number of Cards before the draw : " + iActual + Environment.NewLine + " No. of cards drawn in this Turn = " + NextC);
                    if (ccobjdrw.Remaining == iActual - NextC)
                    {
                        Console.WriteLine("Test Successful: Remaining cards in the deck after the draw:" + ccobjdrw.Remaining + Environment.NewLine + "Press Enter for next draw");
                    }
                    else
                    {
                        Console.WriteLine("Test Fail: Remaining cards:" + ccobjdrw.Remaining);
                    }
                    iActual = ccobjdrw.Remaining;

                    Console.ReadLine();


                }
            }
            catch
            {
                Console.WriteLine("Unable to connect/access the DeckOfcardsapi. Press enter to exit the program.");
                Console.ReadLine();
            }

        }

        static async Task<CCards> GetShuffleCards(string Path)
        {
                CCards ccobj = null;
            try
            {
                HttpResponseMessage respMsg = await CB_A.GetAsync(Path);
                if (respMsg.IsSuccessStatusCode)
                {
                    ccobj = await respMsg.Content.ReadAsAsync<CCards>();
                }
            }
            catch
            {
                Console.WriteLine("Unable to connect/access the DeckOfcardsapi.  Press enter to exit the program.");
                Console.ReadLine();
            }
            return ccobj;
        }
    }
}
